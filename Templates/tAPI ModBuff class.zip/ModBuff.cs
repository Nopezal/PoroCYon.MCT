﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PoroCYon.XnaExtensions;
using PoroCYon.MCT;

namespace $rootnamespace$
{
    [GlobalMod]
    public class $safeitemname$ : TAPI.$safeitemname$
    {
        public $safeitemname$(ModBase @base)
            : base(@base)
        {

        }

        public override void Effects(NPC n, int index)
        {
            base.Effects(n, index);


        }
        public override void Effects(Player p, int index)
        {
            base.Effects(p, index);


        }
    }
}
