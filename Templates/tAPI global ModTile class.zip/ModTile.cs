﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PoroCYon.XnaExtensions;
using TAPI.SDK;

namespace TAPI.$safeprojectname$
{
    [GlobalMod]
    public class $safeitemname$ : TAPI.$safeitemname$
    {
        public $safeitemname$(TAPI.ModBase @base)
            : base(@base)
        {

        }

        public override void Update()
        {
            base.Update();


        }

        public override void Kill(int x, int y)
        {
            base.Kill(x, y);


        }
    }
}
