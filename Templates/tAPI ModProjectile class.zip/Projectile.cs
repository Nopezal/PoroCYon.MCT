﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PoroCYon.XnaExtensions;
using TAPI.SDK;

namespace TAPI.$safeprojectname$
{
    public class $safeitemname$ : TAPI.ModProjectile
    {
        public $safeitemname$(TAPI.ModBase @base, TAPI.$safeitemname$ p)
            : base(@base, p)
        {

        }

        public override void AI()
        {
            base.AI();


        }

        public override void Kill()
        {
            base.Kill();


        }
    }
}
