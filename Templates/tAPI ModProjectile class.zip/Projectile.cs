﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PoroCYon.XnaExtensions;
using Terraria;
using TAPI;
using PoroCYon.MCT;

namespace
#if CREATE_TEMPLATE
    safeprojectname
#else
    $safeprojectname$
#endif
{
    public class $safeitemname$ : TAPI.ModProjectile
    {
        public $safeitemname$(TAPI.ModBase @base, Terraria.$safeitemname$ p)
            : base(@base, p)
        {

        }

        public override void AI()
        {
            base.AI();


        }
        public override void Kill()
        {
            base.Kill();


        }
    }
}
