﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PoroCYon.XnaExtensions;
using PoroCYon.MCT;

namespace TAPI.$safeprojectname$
{
    public class Tile : TAPI.ModTile
    {
        public Tile(TAPI.ModBase @base)
            : base(@base)
        {

        }

        public override void Update()
        {
            base.Update();


        }

        public override void Kill(int x, int y)
        {
            base.Kill(x, y);


        }
    }
}
