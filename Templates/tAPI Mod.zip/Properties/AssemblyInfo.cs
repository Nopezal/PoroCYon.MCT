﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyProduct("$projectname$")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("Mod $projectname$ by $registeredorganization$ v1.0.0.0")]
[assembly: AssemblyCompany("$registeredorganization$")]
[assembly: AssemblyCopyright("Copyright © $registeredorganization$ $year$")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("$guid2$")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
