﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PoroCYon.XnaExtensions;

namespace TAPI.$safeprojectname$
{
    [GlobalMod]
    public class $safeitemname$ : TAPI.$safeitemname$
    {
        public $safeitemname$(TAPI.ModBase @base, TAPI.Projectile p)
            : base(@base, p)
        {

        }

        public override void AI()
        {
            base.AI();


        }

        public override void Kill()
        {
            base.Kill();


        }
    }
}
