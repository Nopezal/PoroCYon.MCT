﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PoroCYon.XnaExtensions;
using Terraria;
using TAPI;
using PoroCYon.MCT;

namespace $safeprojectname$
{
    public sealed class Mod : ModBase
    {
        public Mod()
            : base()
        {
            
        }

        public override void OnLoad()
        {
            base.OnLoad();
        }

        public override void OnAllModsLoaded()
        {
            base.OnAllModsLoaded();
        }
    }
}
